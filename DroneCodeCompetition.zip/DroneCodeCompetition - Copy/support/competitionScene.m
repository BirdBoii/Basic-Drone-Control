function competitionScene(Actor, World)

% Initialize the simulation world and main actor
% World = sim3d.World();
% Actor = sim3d.Actor();
% World.add(Actor);

% Add a grey floor
floor = sim3d.Actor('ActorName', 'floor');
createShape(floor, 'box', [10 10 0.1]); % 10x10 meters floor with 0.1 meters thickness
floor.Color = [0.37 0.5 0.33]; % Grey color
% floorTexture = sim3d.Texture('TextureFile', texturePath);
% floor.Texture = floorTexture;
floor.Metallic = 0.7;
floor.Specular = 0.5;
floor.Flat = 1;
floor.Friction = 0.7;
floor.Restitution = 0.3;
floor.Translation = [0 0 -0.05]; % Slightly below the origin to be at z=0
World.add(floor, Actor);

%Arena = sim3d.Actor('ActorName', 'Arena');
%propagate(Arena, 'OverlapEventEnabled',true);

% Add four pillars at the corners of the arena
pillar_positions = [2 2; -2 2; 2 -2; -2 -2];
for i = 1:4
	pillar = sim3d.Actor('ActorName', ['pillar' num2str(i)]);
	createShape(pillar, 'cylinder', [0.3 0.3 3]); % Height of 3 meters, diameter of 1 inch (0.0254 meters)
	pillar.Translation = [pillar_positions(i, :) 1.5];
	pillar.Color = [0 0 0];
	pillar.Collisions = 0; % Disable Collisions
	% pillar.HitEventEnabled = true;
 %   pillar.Parent = Arena;
	propagate(pillar, 'OverlapEventEnabled',true);

	World.add(pillar, Actor);
end

% Function to create a solid wall
	function createSolidWall(world, actor, baseTranslation, dimensions, rotation)
		wall = sim3d.Actor('ActorName', 'wall');
		createShape(wall, 'box', dimensions);
		wall.Color = [1 1 1]; % White color
		wall.Transparency = 0.8; % Set transparency to 0.8
		wall.Metallic = 0;
		wall.Shininess = 0;
		wall.Collisions = 0; % Disable Collisions
		% wall.HitEventEnabled = true;
		wall.Translation = baseTranslation;
		wall.Rotation = rotation;
		%wall.Parent = Arena;
		propagate(wall, 'OverlapEventEnabled',true);
		world.add(wall, actor);
	end

%World.add(Arena, Actor);
% Define wall parameters
wall_thickness = 0.025; % Thickness of the wall
wall_height = 3; % Height of the wall

% Create the solid walls around the pillars
createSolidWall(World, Actor, [0 2 1.5], [4 wall_thickness wall_height], [0 0 0]);   % Front wall
createSolidWall(World, Actor, [0 -2 1.5], [4 wall_thickness wall_height], [0 0 0]);  % Back wall
createSolidWall(World, Actor, [-2 0 1.5], [wall_thickness 4 wall_height], [0 0 0]);  % Left wall
createSolidWall(World, Actor, [2 0 1.5], [wall_thickness 4 wall_height], [0 0 0]);   % Right wall

initData = struct();
initFilePath = fullfile(slproject.getCurrentProject().RootFolder,"initData.mat");
 
% Load or create initialization data
if isfile(initFilePath)
	initData = load(initFilePath);
else
	% Default values
	% Update initData with the correct coordinates
	% Default values
	initData.Lines = [
		struct('StartX', -1.5, 'StartY', -1, 'EndX', 0.5, 'EndY', -1); % Horizontal part of L
		struct('StartX', 0.45, 'StartY', -1, 'EndX', 0.45, 'EndY', 1) % Vertical part of L
		];

	% Add the red circle as a separate structure
	initData.Circle = struct('X', 0.45, 'Y', 1.2, 'Z', 0.001, 'Diameter', 0.1); % Circle
	% save(initFilePath, '-struct', 'initData');
end

% Create lines based on initialization data
for i = 1:length(initData.Lines)
	startX = initData.Lines(i).StartX;
	startY = initData.Lines(i).StartY;
	endX = initData.Lines(i).EndX;
	endY = initData.Lines(i).EndY;

	% Calculate the length and angle of the line
	lineLength  = sqrt((endX - startX)^2 + (endY - startY)^2);
	angle = atan2(endY - startY, endX - startX);

	% Create the line actor
	line_actor = sim3d.Actor('ActorName', ['line_' num2str(i)]);
	createShape(line_actor, 'box', [lineLength  0.1 0.001]); % Line thickness of 0.1 meters, paper thickness
	line_actor.Color = [1 0 0]; % Red color

	% Set the position to the midpoint of the line
	midX = (startX + endX) / 2;
	midY = (startY + endY) / 2;
	line_actor.Translation = [midX midY 0.001];

	% Set the rotation based on the angle
	line_actor.Rotation = [0 0 angle];
	if isfile(initFilePath)
		line_actor.Color = initData.Color;
	else
		line_actor.Color = [1 0 0];
	end
	% Add the line actor to the world
	World.add(line_actor, Actor);
end

% Create the red circle at the end of the L-shape
red_circle = sim3d.Actor('ActorName', 'red_circle');
createShape(red_circle, 'cylinder', [initData.Circle.Diameter initData.Circle.Diameter 0.001]); % Diameter of 20cm, paper thickness
if isfile(initFilePath)
	red_circle.Color = initData.Color;
else
	red_circle.Color = [1 0 0];
end

red_circle.Translation = [initData.Circle.X initData.Circle.Y initData.Circle.Z]; % 25cm away from the edge of L-shape
World.add(red_circle, Actor);

% Create the blue square at the beginning of L-shape
blue_square = sim3d.Actor('ActorName', 'blue_square');
createShape(blue_square, 'box', [0.3 0.3 0.001]); % 30cm x 30cm, paper thickness
blue_square.Color = [0 0 1]; % Blue color
blue_square.Shininess = 0.2;
blue_square.Metallic = 0.7;
blue_square.Specular = 0.5;
blue_square.Friction = 0.7;
blue_square.Restitution = 0.3;
blue_square.Translation = [-1.45 -0.15 0.001]; % Near the front wall
World.add(blue_square, Actor);

% Create the yellow square at the beginning of L-shape
yellow_square = sim3d.Actor('ActorName', 'yellow_square');
createShape(yellow_square, 'box', [0.3 0.3 0.001]); % 30cm x 30cm, paper thickness
yellow_square.Color = [1 1 0]; % Yellow color
yellow_square.Shininess = 0.2;
yellow_square.Metallic = 0.7;
yellow_square.Specular = 0.5;
yellow_square.Friction = 0.7;
yellow_square.Restitution = 0.3;
yellow_square.Translation = [-1.45 0.5 0.001]; % Near the front wall, aligned with the L shape
World.add(yellow_square, Actor);

% Display the world
% World.Root.propagate('Mobility',2);
% World.run(0.1, inf);
% World.save('newScene.mat');
% World.delete();
end
